#  TCP/IP settings
HOST, PORT = "127.0.0.1", 9997
#The first piece of code written for this Client – Server Python programme is the foundation of the whole project.
# and without this one line of code the client programme would not be able to communicate with the server programme.

#This code is written in its own Python file.
#And will be imported into the client and server Python files to establish communication between these two files.
